#include "show_widget.h"
#include "../settings.h"
#include <QVariant>
#include <QTimerEvent>
#include <QPainter>
#include <QMouseEvent>

#define THIS_WIDTH 250
#define THIS_HEIGHT 150
#define START_X 0
#define START_Y 0
#define OFFSET_X 10
#define OFFSET_Y 0

ShowWidget::ShowWidget(QWidget *parent) :
    QWidget(parent),
    state(false),
    currenImage_X(0),
    myfont("微软雅黑",10),
    bgImage("://img/show.png")
//    bgImage("")
{
    this->setFixedSize(THIS_WIDTH,THIS_HEIGHT);
}

void ShowWidget::loadState(const Settings *config){
    state = config->value("ShowWidget/state",false).toBool();
    usedFlow = config->value("ShowWidget/usedFlow","Null").toString();
    user_id = config->value("ShowWidget/user_id","Null").toString();
    ip_addr = config->value("ShowWidget/ip_addr","Null").toString();
    used_time = config->value("ShowWidget/used_time","Null").toString();
    surplusMoney = config->value("ShowWidget/surplusMoney","Null").toString();
    if(state)
        currenImage_X = THIS_WIDTH;
}

void ShowWidget::saveState(Settings *config){
    if(config->contains("userinfo/list")==true){
        config->beginGroup("ShowWidget");
        config->setValue("state",state);
        config->setValue("user_id",user_id);
        config->setValue("ip_addr",ip_addr);
        config->setValue("used_time",used_time);
        config->setValue("usedFlow",usedFlow);
        config->setValue("surplusMoney",surplusMoney);
        config->endGroup();
    }
    else{
        config->beginGroup("ShowWidget");
        config->remove("");
        config->endGroup();
    }
}

void ShowWidget::setBoardInfo(responseResult &res){

    note = "上网不涉密 涉密不上网！";
    user_id =       "用户账号：" + res.user_name;
    ip_addr =       "网络地址：" + res.ip_addr;
    used_time =     "已用时长：" +  res.sum_seconds;
    usedFlow =      "已用流量：" +  res.usedflow;
    surplusMoney =  "帐户余额：" +  res.surplusmoney;
    state = !state;
    timerID = startTimer(10);
}

void ShowWidget::paintEvent(QPaintEvent *){
    QPainter painter(this);
    painter.setRenderHints(QPainter::SmoothPixmapTransform,true);
    painter.drawImage(START_X,START_Y,bgImage,currenImage_X,START_Y,THIS_WIDTH*2,THIS_HEIGHT);
    if(state==true){
        painter.setFont(myfont);
        //painter.drawText(THIS_WIDTH-currenImage_X+124,29,totalFlow);
        int pos_y = 20;
        int cre_y = 30;
//        painter.drawText(THIS_WIDTH-currenImage_X+30,pos_y,user_id);pos_y += cre_y;
        painter.drawText(THIS_WIDTH-currenImage_X+30,pos_y,user_id);pos_y += cre_y;
        painter.drawText(THIS_WIDTH-currenImage_X+30,pos_y,ip_addr);pos_y += cre_y;
        painter.drawText(THIS_WIDTH-currenImage_X+30,pos_y,usedFlow);pos_y += cre_y;
        painter.drawText(THIS_WIDTH-currenImage_X+30,pos_y,used_time);pos_y += cre_y;
        painter.drawText(THIS_WIDTH-currenImage_X+30,pos_y,surplusMoney);
    }
}

void ShowWidget::timerEvent(QTimerEvent *e){
    if(state==true){
        if(timerID==e->timerId()){
            scroll(-OFFSET_X,OFFSET_Y);
            currenImage_X+=OFFSET_X;
        }
        if(currenImage_X > THIS_WIDTH){
            currenImage_X = THIS_WIDTH;
            update();
            this->killTimer(timerID);
        }}
        if(state==false){
        if(timerID==e->timerId()){
            scroll(OFFSET_X,OFFSET_Y);
            currenImage_X-=OFFSET_X;
        }
        if(currenImage_X < START_X){
            currenImage_X = START_X;
            update();
            this->killTimer(timerID);
        }}
}

void ShowWidget::mousePressEvent(QMouseEvent *e)
{
    press_point = e->pos();
    is_move = true;
}

void ShowWidget::mouseMoveEvent(QMouseEvent *e)
{
    if((e->buttons() == Qt::LeftButton) && is_move)
    {
        static QWidget* parent_widget = this->parentWidget();
        QPoint parent_point = parent_widget->pos();
        parent_point.setX(parent_point.x() + e->x() - press_point.x());
        parent_point.setY(parent_point.y() + e->y() - press_point.y());
        parent_widget->move(parent_point);
    }
}

void ShowWidget::mouseReleaseEvent(QMouseEvent *)
{
    if(is_move)
    {
        is_move = false;
    }
}
