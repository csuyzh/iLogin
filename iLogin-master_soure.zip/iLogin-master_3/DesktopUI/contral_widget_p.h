#ifndef ContralWidget_P_H
#define ContralWidget_P_H

#include <QWidget>
#include "../public_data.h"
class QPushButton;
class QCheckBox;

class ContralWidget : public QWidget
{
    Q_OBJECT
public:
    explicit ContralWidget(QWidget *parent = 0);
    ~ContralWidget();
    bool isRemember();
    bool isAuto();
    void setRole(Role r);
    Role getRole();
    void setCheckboxState(bool re,bool au);
signals:
    void currentRole(Role);
    void roleChanged(Role);
    void userAction(Role);
    void checkboxChanged(Infofiled,bool);
public slots:
    void operateResult(bool);
protected:
    void mousePressEvent(QMouseEvent *);
    void mouseMoveEvent(QMouseEvent *);
    void mouseReleaseEvent(QMouseEvent *);
private slots:
    void clickdButton();
    void clickCheckBox(bool);
    void slotRole(Role);
private:
    QCheckBox *checkbox_rememberthis;
    QCheckBox *checkbox_autologin;
    QPushButton * button_trigger;
    Role role;

    QPoint press_point;//鼠标按下去的点
    bool is_move;
};

#endif // ContralWidget_P_H
