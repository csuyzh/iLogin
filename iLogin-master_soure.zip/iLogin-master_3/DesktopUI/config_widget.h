#ifndef CONFIG_WIDGET_H
#define CONFIG_WIDGET_H

#include <QWidget>

class QCheckBox;
class PushButton;
class QPushButton;
class QLabel;
class QSettings;

class ConfigWidget : public QWidget
{
    Q_OBJECT
public:
    explicit ConfigWidget(QSettings *c, QWidget *parent = 0);
    ~ConfigWidget();
    bool hideLogin()const;
    bool autoBoot()const;
    bool defaultCloseAction()const;
protected:
    void showEvent(QShowEvent *);
    void paintEvent(QPaintEvent *);
    void mouseMoveEvent(QMouseEvent *);
    void mousePressEvent(QMouseEvent *);
    void mouseReleaseEvent(QMouseEvent *);
private slots:
    void save();
private:
    void loadGloableConfig();
    void saveGloableConfig();
private:
    QLabel *label_title;
    PushButton *button_close;
    QCheckBox *checkbox_hideLogin;
    QCheckBox *checkbox_autoBoot;
    QCheckBox *checkbox_defaultCloseAction;
    QPushButton *button_ok;
    QSettings *config;

    QPoint press_point;//鼠标按下去的点
    bool is_move;
};

#endif // CONFIG_WIDGET_H
