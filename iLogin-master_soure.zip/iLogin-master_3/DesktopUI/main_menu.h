#ifndef MAINMENU_H
#define MAINMENU_H

#include <QMenu>

class MainMenu : public QMenu
{
    Q_OBJECT
public:
    explicit MainMenu(QWidget *parent = 0);
signals:
    void openConfig();
    void openAbout();
private slots:
    void openSite();
private:
    QAction *configure;
    QAction *update;
    QAction *selfServe;
    QAction *userRegist;
    QAction *selfServicePaid;
    QAction *ServicePaid;
    QAction *about;
};


#endif // MAINMENU_H
