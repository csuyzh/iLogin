#include "about_widget.h"
#include "push_button_p.h"
#include <QLabel>
#include <QBitmap>
#include <QMouseEvent>
#include <QHBoxLayout>

const char * message1 = "感谢您使用iLogin v3.0,在使用过";
const char * message2 = "程中如有问题,您可发送邮件到:";
const char * message3 = "bityuanzhihua@163.com";
const char * message4 = "iLogin是一款基于Qt5的面向北京理工大学学生的上网验证工";
const char * message5 = "具,该软件遵循GPLv3协议,如需源码请访问我的GitHub地址:";
const char * my_site = "暂未公开，请等待更新";



AboutWidget::AboutWidget(QWidget *parent) :
    QWidget(parent)
{
    this->setFixedSize(400,300);
    this->setWindowFlags(Qt::FramelessWindowHint);
    this->setWindowTitle("iLogin-关于");
    this->setStyleSheet("font: 9pt \"微软雅黑\"");

    QBitmap bmp(this->size());
    bmp.fill();
    QPainter p(&bmp);
    p.setPen(Qt::NoPen);
    p.setBrush(Qt::black);
    p.drawRoundedRect(bmp.rect(),2,2);
    this->setMask(bmp);

    label_title = new QLabel("关于");
    label_title->setContentsMargins(15,5,0,0);
    button_close = new PushButton();
    button_close->loadPixmap("://img/sysButton/close_button.png");
    connect(button_close,SIGNAL(clicked()),this,SLOT(hide()));

    QHBoxLayout *main_layout = new QHBoxLayout;
    main_layout->setContentsMargins(5,0,5,0);
    main_layout->addWidget(label_title,0,Qt::AlignLeft | Qt::AlignTop);
    main_layout->addStretch();
    main_layout->addWidget(button_close,0,Qt::AlignRight | Qt::AlignTop);

    this->setLayout(main_layout);
}

AboutWidget::~AboutWidget(){
    delete button_close;
    delete label_title;
}

void AboutWidget::paintEvent(QPaintEvent *)
{
    QPainter painter(this);
    QLinearGradient gradient(200.0,25.0,200.0,300.0);
    gradient.setColorAt(0.0,QColor("skyblue"));
    gradient.setColorAt(1.0,Qt::white);

    painter.setPen(Qt::NoPen);
    painter.setBrush(QBrush(gradient));
    painter.drawRect(0,0,400,300);
    painter.drawImage(0,70,QImage("://img/show.png"),45,10,210,96);

    painter.setPen(Qt::black);
    painter.setFont(QFont("微软雅黑",9));
    painter.drawText(160,105,tr(message1));
    painter.drawText(160,125,tr(message2));
    painter.drawText(160,145,tr(message3));
    painter.drawText(55,195,tr(message4));
    painter.drawText(55,220,tr(message5));
    painter.drawText(55,245,tr(my_site));
}

void AboutWidget::mousePressEvent(QMouseEvent *e)
{
    press_point = e->pos();
    is_move = true;
}

void AboutWidget::mouseMoveEvent(QMouseEvent *e)
{
    if((e->buttons() == Qt::LeftButton) && is_move)
    {

        QPoint this_point = this->pos();
        this_point.setX(this_point.x() + e->x() - press_point.x());
        this_point.setY(this_point.y() + e->y() - press_point.y());
        this->move(this_point);
    }
}

void AboutWidget::mouseReleaseEvent(QMouseEvent *)
{
    if(is_move)
    {
        is_move = false;
    }
}

