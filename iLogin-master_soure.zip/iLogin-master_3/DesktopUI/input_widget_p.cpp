#include "input_widget_p.h"
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QComboBox>
#include <QToolTip>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QKeyEvent>
#include <QMouseEvent>

InputWidget::InputWidget(QWidget *parent) :
    QWidget(parent)
{
    this->setFixedWidth(301);
    label_account = new QLabel("账号:");
    label_passwd = new QLabel("密码:");
    combobox_account = new QComboBox();
    button_clear = new QPushButton();
    textline_passwd = new QLineEdit();

    label_account->setFont(QFont("微软雅黑",9));
    label_account->setContentsMargins(15,0,0,0);
    label_passwd->setFont(QFont("微软雅黑",9));
    label_passwd->setContentsMargins(15,0,0,0);

    combobox_account->setInsertPolicy(QComboBox::NoInsert);
    combobox_account->setFixedSize(250,35);
    combobox_account->setEditable(true);
    combobox_account->setStyleSheet("font: 11pt \"微软雅黑\"");
    combobox_account->installEventFilter(this);

    button_clear->setFixedSize(25,35);
    button_clear->setFocusPolicy(Qt::NoFocus);
    button_clear->setToolTip("清除当前账号信息");
    button_clear->setIcon(QIcon("://img/sysButton/clear.png"));
    button_clear->hide();
    connect(button_clear,SIGNAL(clicked()),this,SLOT(removeAccount()));

    textline_passwd->setFixedSize(250,35);
    textline_passwd->setEchoMode(QLineEdit::Password);
    textline_passwd->setStyleSheet("font: 11pt \"微软雅黑\"");
    textline_passwd->installEventFilter(this);
    connect(combobox_account,SIGNAL(currentTextChanged(QString)),this,SLOT(showCurentPasswd(QString)));

    QHBoxLayout *line_layout = new QHBoxLayout();
    line_layout->addWidget(combobox_account);
    line_layout->addWidget(button_clear);

    QVBoxLayout *main_layout = new QVBoxLayout();
    main_layout->addWidget(label_account,0,Qt::AlignBottom);
    main_layout->addLayout(line_layout);
    main_layout->addWidget(label_passwd,0,Qt::AlignBottom);
    main_layout->addWidget(textline_passwd,0,Qt::AlignHCenter);

    this->setLayout(main_layout);

}

InputWidget::~InputWidget(){
    delete label_account;
    delete label_passwd;
    delete combobox_account;
    delete textline_passwd;
    delete button_clear;
}

bool InputWidget::existCurrentAccount(){
    QString cur = combobox_account->currentText();
    return combobox_account->findText(cur)==-1?false:true;
}

void InputWidget::addAccountandPasswd(QString acc, QString pas){
    combobox_account->addItem(acc,pas);
}

void InputWidget::setCurrentIndex(int index){
    combobox_account->setCurrentIndex(index);
}

int InputWidget::getCurrentIndex()const{
    QString curText = combobox_account->currentText();
    int result = combobox_account->findText(curText);
    return result;
}

QString InputWidget::getCurrentAccount() const{
    return combobox_account->currentText();
}

void InputWidget::setCurrentAccount(QString acc){
    combobox_account->setEditText(acc);
}

QString InputWidget::getCurrentPasswd() const{
    return textline_passwd->text();
}


void InputWidget::setPasswd(QString s){
    textline_passwd->setText(s);
}

void InputWidget::showAccontTip(){
    QToolTip::showText(combobox_account->mapToGlobal(QPoint(-5,15)),"账号不能为空");
}

void InputWidget::showPassTip(){
    QToolTip::showText(textline_passwd->mapToGlobal(QPoint(-5,15)),"密码不能为空");
}

bool InputWidget::eventFilter(QObject *obj, QEvent *e){
    if(obj==combobox_account||obj==textline_passwd){
        if(e->type()==QEvent::KeyPress){
            QKeyEvent* ke = static_cast<QKeyEvent*>(e);
            if(ke->key()==Qt::Key_Return){
                if(combobox_account->currentText().length()==0){
                    this->showAccontTip();
                    return true;
                }
                if(textline_passwd->text().length()==0){
                    this->showPassTip();
                    return true;
                }
                emit transformUserInform(combobox_account->currentText(),textline_passwd->text());
                return true;
            }
            return QWidget::eventFilter(obj,e);
        }
        return QWidget::eventFilter(obj,e);
    }
    return QWidget::eventFilter(obj,e);
}

void InputWidget::showCurentPasswd(QString s){
    int index = combobox_account->findText(s);
    if(index!=-1){
        QString tmp = combobox_account->itemData(index).toString();
        textline_passwd->setText(tmp);
    }
    else
        textline_passwd->clear();
    if(combobox_account->count()==0)
        textline_passwd->clear();
    emit currentIndexChanged(index);
}

void InputWidget::removeAccount(){
    int index = combobox_account->findText(combobox_account->currentText());
    if(index==-1)
        combobox_account->setEditText("");
    else{
        combobox_account->removeItem(index);
        emit removeIndexAccount(index);
    }

}

void InputWidget::mousePressEvent(QMouseEvent *e)
{
    press_point = e->pos();
    is_move = true;
}

void InputWidget::mouseMoveEvent(QMouseEvent *e)
{
    if((e->buttons() == Qt::LeftButton) && is_move)
    {
        static QWidget* parent_widget = this->parentWidget();
        QPoint parent_point = parent_widget->pos();
        parent_point.setX(parent_point.x() + e->x() - press_point.x());
        parent_point.setY(parent_point.y() + e->y() - press_point.y());
        parent_widget->move(parent_point);
    }
}

void InputWidget::mouseReleaseEvent(QMouseEvent *)
{
    if(is_move)
    {
        is_move = false;
    }
}


/*
 *-------------------------------------------------------------------------
 */

/*
AccountItem_p::AccountItem_p(QWidget *parent):
    QWidget(parent)
{
    ispress = false;
    label_account = new QLabel("sdfsdf");
    button_clear = new QPushButton();
    button_clear->setFixedSize(16,16);
    button_clear->setIcon(QIcon("://img/sysButton/clear.png"));
    button_clear->setIconSize(QSize(15,15));
    button_clear->setStyleSheet("background:transparent;");
    connect(button_clear,SIGNAL(clicked()),this,SLOT(removeItem()));

    main_layout = new QHBoxLayout();
    main_layout->addWidget(label_account,0,Qt::AlignTop);
    main_layout->addStretch();
    main_layout->addWidget(button_clear,0,Qt::AlignTop);
    main_layout->setContentsMargins(5, 5, 5, 5);
     main_layout->setSpacing(5);


    this->setLayout(main_layout);
}

AccountItem_p::~AccountItem_p(){

}

QString AccountItem_p::getItemText() const{
    return label_account->text();
}

void AccountItem_p::setItemText(QString &s){
    label_account->setText(s);
}

void AccountItem_p::removeItem(){
    emit removeItem(label_account->text());
}

void AccountItem_p::showItem(){
    emit showItem(label_account->text());
}
*/
