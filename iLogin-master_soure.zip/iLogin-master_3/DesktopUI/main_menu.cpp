#include "main_menu.h"
#include <QDesktopServices>
#include <QUrl>


MainMenu::MainMenu(QWidget *parent) :
    QMenu(parent)
{
    configure = new QAction(QIcon("://img/sysButton/configure.png"),"设置",this);
    connect(configure,SIGNAL(triggered()),this,SIGNAL(openConfig()));
    this->addAction(configure);

    update = new QAction("检查更新",this);
    update->setObjectName("update");
    connect(update,SIGNAL(triggered()),this,SLOT(openSite()));
    this->addAction(update);

    selfServe = new QAction("自服务",this);
    selfServe->setObjectName("selfServe");
    connect(selfServe,SIGNAL(triggered()),this,SLOT(openSite()));
    this->addAction(selfServe);

    userRegist = new QAction("用户注册",this);
    userRegist->setObjectName("userRegist");
    connect(userRegist,SIGNAL(triggered()),this,SLOT(openSite()));
    this->addAction(userRegist);

    selfServicePaid = new QAction("在线充值",this);
    selfServicePaid->setObjectName("selfServicePaid");
    connect(selfServicePaid,SIGNAL(triggered()),this,SLOT(openSite()));
    this->addAction(selfServicePaid);

    ServicePaid = new QAction("经费卡充值",this);
    ServicePaid->setObjectName("ServicePaid");
    connect(ServicePaid,SIGNAL(triggered()),this,SLOT(openSite()));
    this->addAction(ServicePaid);

    selfServe = new QAction("自服务",this);
    connect(selfServe,SIGNAL(triggered()),this,SLOT(openSite()));

    about = new QAction("关于",this);
    connect(about,SIGNAL(triggered()),this,SIGNAL(openAbout()));
    this->addAction(about);

}

void MainMenu::openSite(){
    QUrl url;
    if(sender()->objectName()=="selfServe")
        url.setUrl("http://10.0.0.55:8800/");
    if(sender()->objectName()=="userRegist")
        url.setUrl("https://login.bit.edu.cn/cas/login");
    if(sender()->objectName()=="selfServicePaid")
        url.setUrl("http://nsc-mis.info.bit.edu.cn/selfServicePaid");
    if(sender()->objectName()=="ServicePaid")
        url.setUrl("http://nsc-mis.info.bit.edu.cn/");
    if(sender()->objectName()=="update")
        url.setUrl("http://pan.baidu.com/share/link?shareid=587551069&uk=2486550955#dir/path=%2FiLogin");
    QDesktopServices::openUrl(url);
}

