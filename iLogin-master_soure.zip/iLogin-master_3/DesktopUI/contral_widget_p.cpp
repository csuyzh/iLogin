#include "contral_widget_p.h"
#include <QCheckBox>
#include <QPushButton>
#include <QVBoxLayout>
#include <QMouseEvent>

ContralWidget::ContralWidget(QWidget *parent) :
    QWidget(parent)
{
    this->setFixedSize(300,150);
    this->setStyleSheet("font: 9pt \"微软雅黑\"");

    checkbox_autologin = new QCheckBox("自动登录");
    checkbox_rememberthis = new QCheckBox("记住密码");
    button_trigger = new QPushButton("登陆");
    role = LOGIN_BUTTON;

    checkbox_rememberthis->setObjectName("checkbox_rememberthis");
    checkbox_autologin->setObjectName("checkbox_autologin");

    button_trigger->setFixedSize(91,32);

    QVBoxLayout *main_layout = new QVBoxLayout;
    main_layout->setMargin(40);
    main_layout->addWidget(checkbox_rememberthis,0,Qt::AlignLeft);
    main_layout->addWidget(checkbox_autologin,0,Qt::AlignLeft);
    main_layout->addSpacing(20);
    main_layout->addWidget(button_trigger,0,Qt::AlignCenter);

    connect(button_trigger,SIGNAL(clicked()),this,SLOT(clickdButton()));
    connect(checkbox_rememberthis,SIGNAL(clicked(bool)),this,SLOT(clickCheckBox(bool)));
    connect(checkbox_autologin,SIGNAL(clicked(bool)),this,SLOT(clickCheckBox(bool)));
    connect(this,SIGNAL(roleChanged(Role)),this,SLOT(slotRole(Role)));

    this->setLayout(main_layout);
}

ContralWidget::~ContralWidget(){
    delete checkbox_autologin;
    delete checkbox_rememberthis;
    delete button_trigger;
}

bool ContralWidget::isRemember(){
    return checkbox_rememberthis->isChecked();
}

bool ContralWidget::isAuto(){
    return checkbox_autologin->isChecked();
}

void ContralWidget::setRole(Role r){
    role = r;
    emit roleChanged(role);
}

Role ContralWidget::getRole(){
    return role;
}

void ContralWidget::setCheckboxState(bool re,bool au){
    checkbox_rememberthis->setChecked(re);
    checkbox_autologin->setChecked(au);
}

void ContralWidget::clickdButton(){
    //this->setEnabled(false);
    switch(role){
    case LOGIN_BUTTON:
        button_trigger->setText(tr("登录ing..."));
        emit userAction(LOGIN_BUTTON);
        break;
    case LOGOUT_BUTTON:
        button_trigger->setText(tr("离开ing..."));
        emit userAction(LOGOUT_BUTTON);
        break;
    }
}

void ContralWidget::clickCheckBox(bool checked){
    QString name = sender()->objectName();
    if(name=="checkbox_rememberthis"){
        emit checkboxChanged(ISREM,checked);
    }
    if(name=="checkbox_autologin"){
        emit checkboxChanged(ISAUTO,checked);
    }
}

void ContralWidget::operateResult(bool r){
    this->setEnabled(true);
    if(r==true){
        switch(role){
        case LOGIN_BUTTON:
            role = LOGOUT_BUTTON;
            break;
        case LOGOUT_BUTTON:
            role = LOGIN_BUTTON;
            break;
        }
    }
    emit roleChanged(role);
}

void ContralWidget::slotRole(Role r){
    switch(r){
    case LOGIN_BUTTON:
        checkbox_autologin->setEnabled(true);
        checkbox_rememberthis->setEnabled(true);
        button_trigger->setText("登陆");
        break;
    case LOGOUT_BUTTON:
        checkbox_autologin->setEnabled(false);
        checkbox_rememberthis->setEnabled(false);
        button_trigger->setText("离开");
        break;
    }
}

void ContralWidget::mousePressEvent(QMouseEvent *e)
{
    press_point = e->pos();
    is_move = true;
}

void ContralWidget::mouseMoveEvent(QMouseEvent *e)
{
    if((e->buttons() == Qt::LeftButton) && is_move)
    {
        static QWidget* parent_widget = this->parentWidget();
        QPoint parent_point = parent_widget->pos();
        parent_point.setX(parent_point.x() + e->x() - press_point.x());
        parent_point.setY(parent_point.y() + e->y() - press_point.y());
        parent_widget->move(parent_point);
    }
}

void ContralWidget::mouseReleaseEvent(QMouseEvent *)
{
    if(is_move)
    {
        is_move = false;
    }
}

