#ifndef MAINUI_H
#define MAINUI_H

#include <QWidget>
#include "title_widget_p.h"
#include "main_menu.h"
#include "system_tray_p.h"
#include "input_widget_p.h"
#include "contral_widget_p.h"
#include "show_widget.h"
#include "config_widget.h"
#include "about_widget.h"
#include "../public_data.h"
#include "../net_contral.h"
#include "../settings.h"

class MainUI : public QWidget
{
    Q_OBJECT
    
public:
    MainUI(QWidget *parent = 0);
    ~MainUI();
public slots:
    void showMainMenu();
    void showNetError(QString);                 //响应错误并显示
    void closeAction();
    void closeAction1();
    void handleTrayAction(Role);
    void handleCheckboxChanged(Infofiled,bool);
    void handleAction(Role);                    //响应button
    void handleCurrentIndexChanged(int);
    void handleIndexAccountRemove(int);
    void handleTransfomData(QString,QString);    //响应用户在输入框的回车键
    void handleNetResult(responseResult);       //处理成功登陆后的结果
protected:
    void paintEvent(QPaintEvent *);
    void timerEvent(QTimerEvent *);
    bool nativeEvent(const QByteArray &eventType, void *message, long *result);
private:
    void initState();
private:
    TitleWidget * titlewidget;
    MainMenu *mainmenu;
    SystemTray * systemtray;
    InputWidget *inputwidget;
    ContralWidget *contralwidget;
    ShowWidget *showwidget;
    ConfigWidget *configwidget;
    AboutWidget *aboutwidget;
    NetContral *netcontral;
    Settings *settings;

    int timeID;
    QEventLoop *eventloop;  //该事件循环用于关机时程序的响应
};

#endif // MAINUI_H
