#ifndef TITLE_WIDGET_H
#define TITLE_WIDGET_H

#include <QWidget>
#include "push_button_p.h"

class QLabel;

class TitleWidget : public QWidget
{
    Q_OBJECT
public:
    explicit TitleWidget(QWidget *parent = 0);
    ~TitleWidget();
signals:
    void showMin();
    void showMainMenu();
    void closeWidget();
protected:
    void mousePressEvent(QMouseEvent *);
    void mouseMoveEvent(QMouseEvent *);
    void mouseReleaseEvent(QMouseEvent *);
private:
    QLabel *version_title; //标题
    PushButton *main_menu_button; //主菜单
    PushButton *min_button; //最小化
    PushButton *close_button; //关闭

    QPoint press_point;//鼠标按下去的点
    bool is_move;
};

#endif // TITLE_WIDGET_H
