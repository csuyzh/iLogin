#include "mainui.h"
#include <QVBoxLayout>
#include <QToolTip>
#include <QMessageBox>
#include <QApplication>
#include <QDesktopWidget>
#include <QBitmap>
#ifdef Q_OS_WIN
#include <Windows.h>
#endif

MainUI::MainUI(QWidget *parent)
    : QWidget(parent)
{
    this->resize(301,536);
    this->setWindowFlags(Qt::FramelessWindowHint | Qt::Tool | Qt::WindowStaysOnTopHint);

    QBitmap bmp(this->size());
    bmp.fill();
    QPainter p(&bmp);
    p.setPen(Qt::NoPen);
    p.setBrush(Qt::black);
    p.drawRoundedRect(bmp.rect(),3,3);
    this->setMask(bmp);

    //对象初始化
    systemtray = new SystemTray(this);
    netcontral = new NetContral(this);
    settings = new Settings(this);
    eventloop = new QEventLoop(this);
    titlewidget = new TitleWidget();
    mainmenu = new MainMenu();
    showwidget = new ShowWidget();
    inputwidget = new InputWidget();
    contralwidget = new ContralWidget();
    configwidget = new ConfigWidget(settings);
    aboutwidget = new AboutWidget();

    initState();

    connect(titlewidget,SIGNAL(showMainMenu()),this,SLOT(showMainMenu()));
    connect(titlewidget,SIGNAL(showMin()),this,SLOT(hide()));
    connect(titlewidget,SIGNAL(closeWidget()),this,SLOT(closeAction1()));
    connect(mainmenu,SIGNAL(openConfig()),configwidget,SLOT(show()));
    connect(mainmenu,SIGNAL(openAbout()),aboutwidget,SLOT(show()));
    connect(systemtray,SIGNAL(triggerLeftButton()),this,SLOT(show()));
    connect(systemtray,SIGNAL(triggerAction(Role)),this,SLOT(handleTrayAction(Role)));
    connect(systemtray,SIGNAL(triggerQuitAction()),this,SLOT(closeAction()));
    connect(inputwidget,SIGNAL(transformUserInform(QString,QString)),this,SLOT(handleTransfomData(QString,QString)));
    connect(inputwidget,SIGNAL(currentIndexChanged(int)),this,SLOT(handleCurrentIndexChanged(int)));
    connect(inputwidget,SIGNAL(removeIndexAccount(int)),this,SLOT(handleIndexAccountRemove(int)));
    connect(contralwidget,SIGNAL(userAction(Role)),this,SLOT(handleAction(Role)));
    connect(contralwidget,SIGNAL(checkboxChanged(Infofiled,bool)),this,SLOT(handleCheckboxChanged(Infofiled,bool)));
    connect(netcontral,SIGNAL(error(QString)),this,SLOT(showNetError(QString)));
    connect(netcontral,SIGNAL(responseInfo(responseResult)),this,SLOT(handleNetResult(responseResult)));

    //布局管理
    QVBoxLayout *main_layout = new QVBoxLayout();
    main_layout->addWidget(titlewidget);
    main_layout->addWidget(showwidget,0,Qt::AlignHCenter|Qt::AlignBottom);
    main_layout->addWidget(inputwidget);
    main_layout->addWidget(contralwidget);
    main_layout->setContentsMargins(0,0,0,0);
    this->setLayout(main_layout);
    systemtray->show();
    QRect rec=qApp->desktop()->availableGeometry();
    this->move(rec.width()-320,90);

//    //判断是否在线，若在线，则先强制下线
//    if(Ping()){

//    }

    //执行自动登录相关操作
    if(contralwidget->isAuto()){
        handleAction(LOGIN_BUTTON);
        if(configwidget->hideLogin())
            return;
    }
    this->show();
}

MainUI::~MainUI()
{
    delete titlewidget;
    delete mainmenu;
    delete showwidget;
    delete inputwidget;
    delete contralwidget;
    delete configwidget;
    delete aboutwidget;
}

//显示主界面
void MainUI::showMainMenu(){
    QPoint p1 = this->rect().topRight();
    QPoint p2 = this->pos();
    p1.setX(p1.x() - 116);
    p1.setY(p1.y() + 20);
    p2.setX(p2.x()-252);
    configwidget->move(p2);
    mainmenu->exec(this->mapToGlobal(p1));
}

//托盘退出
void MainUI::closeAction(){
    //如果选择了退出时自动下线，当前在线，先退出
        if(netcontral->isOnline())
            netcontral->logout();
        qApp->quit();
}
//界面退出，在线则最小化，不在线则直接退出
void MainUI::closeAction1(){
    //如果当前在线，默认为最小化
    if(netcontral->isOnline())
        this->hide();
    else
        qApp->quit();
}
void MainUI::handleTrayAction(Role r){

    if(r==LOGIN_BUTTON && netcontral->isOnline()==false){
        this->handleAction(r);
        return;
    }
    if(r==LOGOUT_BUTTON && netcontral->isOnline()==true)
        this->handleAction(r);
}

void MainUI::handleCheckboxChanged(Infofiled filed, bool value){
    int index = inputwidget->getCurrentIndex();
    settings->modifyUserInfo(index,filed,value);
}

void MainUI::handleAction(Role r){
    QString account = inputwidget->getCurrentAccount();
    QString pass = inputwidget->getCurrentPasswd();
    contralwidget->setEnabled(false);
    //登录相关操作
    switch(r){
    case LOGIN_BUTTON:
        if(account.length()==0){
           inputwidget->showAccontTip();
           contralwidget->operateResult(false);
           return;
        }
        if(pass.length()==0){
            inputwidget->showPassTip();
            contralwidget->operateResult(false);
            return;
        }
        inputwidget->setEnabled(false);
        //qApp->processEvents();
        netcontral->login(account,pass);
        break;
    case LOGOUT_BUTTON:
        netcontral->logout();
        break;
    }
}

void MainUI::handleTransfomData(QString acc, QString pas){
    inputwidget->setEnabled(false);
    contralwidget->setEnabled(false);
    //登录相关操作
    //qApp->processEvents();
    netcontral->login(acc,pas);
}

void MainUI::handleCurrentIndexChanged(int index){
    if(index>-1){
    const UserInfo tmp = settings->getUserInfo(index);
    contralwidget->setCheckboxState(tmp.isRem,tmp.isAuto);
    }
    else
        contralwidget->setCheckboxState(false,false);
}

void MainUI::handleIndexAccountRemove(int index){
    if(index>-1 && index<settings->getDBCount())
        settings->removeUserInfo(index);
}

void MainUI::showNetError(QString err){
    QApplication::setQuitOnLastWindowClosed(false);
    QMessageBox::information(0,"iLogin",err,QMessageBox::Ok);
    switch(contralwidget->getRole()){
    case LOGIN_BUTTON:
        inputwidget->setEnabled(true);
        break;
    case LOGOUT_BUTTON:
        inputwidget->setEnabled(false);
        break;
    }
    contralwidget->operateResult(false);
}

//响应登录登出按钮
void MainUI::handleNetResult(responseResult res){
    switch(contralwidget->getRole()){
    case LOGIN_BUTTON:
        if(inputwidget->existCurrentAccount()==false)      //不存在账户
        {
            bool isAuto = contralwidget->isAuto();          //是否自动登录
            bool isRem = contralwidget->isRemember();       //是否记住密码
            QString pas;
            if(isRem==true)     //记住密码
                pas = inputwidget->getCurrentPasswd();
            QString acc = inputwidget->getCurrentAccount();
            inputwidget->addAccountandPasswd(acc,pas);
            UserInfo user ={acc,pas,isAuto,isRem};
            settings->addUserInfo(user);
            settings->setLastIndex(inputwidget->getCurrentIndex());
        }
        else{
            int index = inputwidget->getCurrentIndex();
            bool isRem = contralwidget->isRemember();
            settings->modifyUserInfo(index,PASSWD,isRem?inputwidget->getCurrentPasswd():"");
        }
        systemtray->setToolTip("iLogin-Online");
        if(!this->isVisible())
            systemtray->setInformTip(res);
    break;
    case LOGOUT_BUTTON:
        inputwidget->setEnabled(true);
        systemtray->setToolTip("iLogin-Offline");
        break;
    }

    netcontral->saveCurrentState(settings);
    showwidget->setBoardInfo(res);
    showwidget->saveState(settings);
    contralwidget->operateResult(true);
}

void MainUI::paintEvent(QPaintEvent *){
    QPainter painter(this);
    QLinearGradient gradient(150.0,150.0,150.0,600.0);
    gradient.setColorAt(0.0,QColor("skyblue"));
    gradient.setColorAt(1.0,Qt::white);

    painter.setPen(Qt::NoPen);
    painter.setBrush(QBrush(gradient));
    painter.drawRect(0,0,301,536);
}

void MainUI::timerEvent(QTimerEvent *e){
    if(e->timerId()==timeID){
        this->killTimer(timeID);
        settings->remove("recordeflag");
        settings->beginGroup("NetContral");
        settings->remove("");
        settings->endGroup();
        if(eventloop->isRunning()==true){
            eventloop->quit();
            return;
        }
        qApp->quit();
    }
}

//捕获平台关机事件，关机时自动下线
bool MainUI::nativeEvent(const QByteArray &eventType, void *message, long *result){
#ifdef Q_OS_WIN
    MSG *msg = (MSG *)message;
    if(msg->message == WM_QUERYENDSESSION && netcontral->isOnline()){
        disconnect(netcontral,SIGNAL(responseInfo(responseResult)),this,SLOT(handleNetResult(responseResult)));
        netcontral->logout();
        timeID = startTimer(1500);
        eventloop->exec();
    }
#endif
    return QWidget::nativeEvent(eventType,message,result);
}

void MainUI::initState(){
    //判断参数有效性来选择加载某些状态
    if(settings->isParameterValidate()==true){
        netcontral->loadLastState(settings);
        showwidget->loadState(settings);
        contralwidget->setRole(LOGOUT_BUTTON);
        inputwidget->setEnabled(false);
    }
    //加载用户信息
    int count = settings->getDBCount();
    int lastindex = settings->getLastIndex();
    for(int i=0;i<count;i++){
        UserInfo tmp = settings->getUserInfo(i);
        inputwidget->addAccountandPasswd(tmp.account,tmp.passwd);
    }
    if(lastindex>-1&&lastindex<count){
        UserInfo tmp = settings->getUserInfo(lastindex);
        inputwidget->setCurrentAccount(tmp.account);
        contralwidget->setCheckboxState(tmp.isRem,tmp.isAuto);
    }

    if(netcontral->isOnline()){
        systemtray->setToolTip("iLogin-Online");
    }
    else{
        systemtray->setToolTip("iLogin-Offline");
    }
}
