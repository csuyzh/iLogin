#ifndef SYSTEMTRAY_H
#define SYSTEMTRAY_H

#include <QSystemTrayIcon>
#include "../public_data.h"

class QMenu;
class QAction;
class QWidget;

class SystemTray : public QSystemTrayIcon
{
    Q_OBJECT
public:
    explicit SystemTray(QWidget *parent = 0);
    void setInformTip(responseResult&);
signals:
    void triggerLeftButton();
    void triggerAction(Role);
    void triggerQuitAction();
private slots:
    void pressButton(QSystemTrayIcon::ActivationReason r);
    void pressButton();
private:

    void initMenu();

    QMenu *tray_menu;           //托盘菜单
    QAction *action_open;       //打开iLogin窗口
    QAction *action_online;     //上线
    QAction *action_offline;    //下线
    QAction *action_quit;       //退出
};

#endif // SYSTEMTRAY_H
