#ifndef SHOWWIDGET_H
#define SHOWWIDGET_H

#include <QWidget>
#include "../public_data.h"

class Settings;

class ShowWidget : public QWidget
{
public:
    explicit ShowWidget(QWidget *parent = 0);
    void loadState(const Settings*);
    void saveState(Settings*);
    void setBoardInfo(responseResult&);
protected:
    void paintEvent(QPaintEvent *);
    void timerEvent(QTimerEvent *);
    void mousePressEvent(QMouseEvent *);
    void mouseMoveEvent(QMouseEvent *);
    void mouseReleaseEvent(QMouseEvent *);
private:
    bool state;          //标识当前显示状态，false显示的为logo
    int currenImage_X;      //当前图片的起始位置
    int timerID;            //计时器识别器
    QFont myfont;           //字体
//    QString totalFlow;          //总流量
    QString note;
    QString user_id;
    QString ip_addr;
    QString used_time;
    QString usedFlow;           //使用流量
    QString surplusMoney;        //余额
    QImage bgImage;         //背景图片

    QPoint press_point;//鼠标按下去的点
    bool is_move;
};

#endif // SHOWWIDGET_H
