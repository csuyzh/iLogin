#include "config_widget.h"
#include <QCheckBox>
#include <QLabel>
#include <QSettings>
#include "push_button_p.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QMouseEvent>
#include <QFile>
#include <QDir>
#include <QBitmap>

ConfigWidget::ConfigWidget(QSettings *c,QWidget *parent) :
    QWidget(parent),
    config(c)
{
    this->setWindowFlags(Qt::FramelessWindowHint);
    this->setStyleSheet("font: 9pt \"微软雅黑\"");
    this->setWindowTitle("iLogin-设置");
    this->setFixedSize(250,160);

    QBitmap bmp(this->size());
    bmp.fill();
    QPainter p(&bmp);
    p.setPen(Qt::NoPen);
    p.setBrush(Qt::black);
    p.drawRoundedRect(bmp.rect(),2,2);
    this->setMask(bmp);

    label_title = new QLabel("设置");
    button_close = new PushButton();
    checkbox_autoBoot = new QCheckBox("开机自启");
    checkbox_hideLogin = new QCheckBox("静默登陆");
    checkbox_defaultCloseAction = new QCheckBox("关闭时自动下线");
    button_ok = new QPushButton("确认");

    button_close->loadPixmap("://img/sysButton/close_button.png");

    connect(button_ok,SIGNAL(clicked()),this,SLOT(save()));
    connect(button_close,SIGNAL(clicked()),this,SLOT(hide()));

    QHBoxLayout *title_layout = new QHBoxLayout();
    label_title->setContentsMargins(0,5,0,0);
    //title_layout->setContentsMargins(0,0,0,0);
    title_layout->addWidget(label_title,0,Qt::AlignLeft|Qt::AlignTop);
    title_layout->addSpacing(0);
    title_layout->addWidget(button_close,0,Qt::AlignRight|Qt::AlignTop);

    QVBoxLayout *main_layout =new QVBoxLayout();
    main_layout->addLayout(title_layout);
    main_layout->addWidget(checkbox_autoBoot,0,Qt::AlignLeft);
    main_layout->addWidget(checkbox_hideLogin,0,Qt::AlignLeft);
    main_layout->addWidget(checkbox_defaultCloseAction,1,Qt::AlignLeft);
    main_layout->addWidget(button_ok,0,Qt::AlignRight);
    main_layout->setContentsMargins(10,0,5,5);

    this->setLayout(main_layout);
    loadGloableConfig();
}

ConfigWidget::~ConfigWidget(){
    config = NULL;
    delete label_title;
    delete button_close;
    delete checkbox_autoBoot;
    delete checkbox_hideLogin;
    delete checkbox_defaultCloseAction;
    delete button_ok;
}

bool ConfigWidget::autoBoot()const{
    return checkbox_autoBoot->isChecked();
}

bool ConfigWidget::hideLogin()const{
    return checkbox_hideLogin->isChecked();
}

bool ConfigWidget::defaultCloseAction()const{
    return checkbox_defaultCloseAction->isChecked();
}

void ConfigWidget::save(){
    if(autoBoot()!=config->value("GloableConfig/autoBoot",false).toBool()){

        //Windows下开机自启动
#ifdef Q_OS_WIN
        QString ShortCut = QDir::homePath()+"/AppData/Roaming/Microsoft/Windows/Start Menu/Programs/Startup/iLogin.lnk";
        if(autoBoot()==true)
            QFile::link("iLogin.exe",ShortCut);
        else
            QFile::remove(ShortCut);
#endif
    }
    saveGloableConfig();
    hide();
}

void ConfigWidget::showEvent(QShowEvent *e){
    loadGloableConfig();
    QWidget::showEvent(e);
}

void ConfigWidget::paintEvent(QPaintEvent *){
    QPainter painter(this);
    QLinearGradient gradient(125.0,25.0,125.0,160.0);
    gradient.setColorAt(0.0,QColor("skyblue"));
    gradient.setColorAt(1.0,Qt::white);

    painter.setPen(Qt::NoPen);
    painter.setBrush(QBrush(gradient));
    painter.drawRect(0,0,250,160);
}

void ConfigWidget::mousePressEvent(QMouseEvent *e)
{
    press_point = e->pos();
    is_move = true;
}

void ConfigWidget::mouseMoveEvent(QMouseEvent *e)
{
    if((e->buttons() == Qt::LeftButton) && is_move)
    {

        QPoint this_point = this->pos();
        this_point.setX(this_point.x() + e->x() - press_point.x());
        this_point.setY(this_point.y() + e->y() - press_point.y());
        this->move(this_point);
    }
}

void ConfigWidget::mouseReleaseEvent(QMouseEvent *)
{
    if(is_move)
    {
        is_move = false;
    }
}

void ConfigWidget::loadGloableConfig(){
    checkbox_autoBoot->setChecked(config->value("GloableConfig/autoBoot",false).toBool());
    checkbox_hideLogin->setChecked(config->value("GloableConfig/hideLogin",false).toBool());
    checkbox_defaultCloseAction->setChecked(config->value("GloableConfig/defaultCloseAction",false).toBool());
}

void ConfigWidget::saveGloableConfig(){
    config->beginGroup("GloableConfig");
    config->setValue("autoBoot",checkbox_autoBoot->isChecked());
    config->setValue("hideLogin",checkbox_hideLogin->isChecked());
    config->setValue("defaultCloseAction",checkbox_defaultCloseAction->isChecked());
    config->endGroup();
}
