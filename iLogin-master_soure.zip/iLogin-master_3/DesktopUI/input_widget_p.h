#ifndef INPUT_WIDGET_P_H
#define INPUT_WIDGET_P_H

#include <QWidget>


class QLabel;
class QLineEdit;
class QComboBox;
class QPushButton;
class QHBoxLayout;

class InputWidget : public QWidget
{
    Q_OBJECT
public:
    explicit InputWidget(QWidget *parent = 0);
    ~InputWidget();
    bool existCurrentAccount();
    void addAccountandPasswd(QString acc,QString pas);          //添加一条新的账户信息
    void setCurrentIndex(int);
    int getCurrentIndex() const;
    QString getCurrentAccount() const;              //获取当前账户
    void setCurrentAccount(QString);
    QString getCurrentPasswd() const;               //获取当前账户密码
    void setPasswd(QString );
    void showAccontTip();
    void  showPassTip();
    bool eventFilter(QObject *, QEvent *);          //重载事件过滤器，这里主要是用来捕获Enter用的
signals:
    void transformUserInform(QString,QString);      //enter登陆用信号，传递账户和密码
    void currentIndexChanged(int index);
    void removeIndexAccount(int index);
protected:
    void mousePressEvent(QMouseEvent *);
    void mouseMoveEvent(QMouseEvent *);
    void mouseReleaseEvent(QMouseEvent *);
private slots:
    void showCurentPasswd(QString);         //密码显示控制
    void removeAccount();                   //清除按钮对应槽
private:
    QLabel * label_account;     //账号字样显示
    QComboBox * combobox_account;       //账号输入等
    QPushButton *button_clear;
    QLabel * label_passwd;              //密码字样显示
    QLineEdit * textline_passwd;        //密码输入

    QPoint press_point;//鼠标按下去的点
    bool is_move;
};


#endif // INPUT_WIDGET_P_H
