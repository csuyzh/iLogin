#include "system_tray_p.h"
#include <QMenu>
#include <QAction>
#include <QApplication>

SystemTray::SystemTray(QWidget *parent) :
    QSystemTrayIcon(parent)
{
    initMenu();
    connect(this,SIGNAL(activated(QSystemTrayIcon::ActivationReason)),this,SLOT(pressButton(QSystemTrayIcon::ActivationReason)));
    this->setIcon(QIcon("://img/icon.png"));
}

void SystemTray::setInformTip(responseResult &res){
    QString tip = QString("登陆成功！\n用户名:%1\nIP地址:%2\n已用流量:%3\n已用时长:%4\n账户余额:%5")
            .arg(res.user_name).arg(res.ip_addr).arg(res.usedflow).arg(res.sum_seconds).arg(res.surplusmoney);
    this->showMessage("",tip,Information,8000);
//    QString tip = QString("本月流量:%1MB\n已用流量:%2MB\n账户余额:%3元").arg(res.totalflow).arg(res.usedflow).arg(res.surplusmoney);
//    this->showMessage("",tip,Information,8000);
}

void SystemTray::pressButton(QSystemTrayIcon::ActivationReason r){
    if(r==QSystemTrayIcon::Trigger)
        emit triggerLeftButton();
}

void SystemTray::pressButton(){
    QString name = sender()->objectName();
    if(name == "online")
        emit triggerAction(LOGIN_BUTTON);
    else
        emit triggerAction(LOGOUT_BUTTON);
}

void SystemTray::initMenu(){
    tray_menu = new QMenu();

    action_open = new QAction("显示界面",this);
    action_online = new QAction(QIcon("://img/sysButton/online.png"),"登陆",this);
    action_offline = new QAction(QIcon("://img/sysButton/offline.png"),"离开",this);
    action_quit = new QAction("关闭",this);

    action_online->setObjectName("online");
    action_offline->setObjectName("offline");

    tray_menu->addAction(action_open);
    tray_menu->addAction(action_online);
    tray_menu->addAction(action_offline);
    tray_menu->addAction(action_quit);

    connect(action_quit,SIGNAL(triggered()),this,SIGNAL(triggerQuitAction()));
    connect(action_open,SIGNAL(triggered()),this,SIGNAL(triggerLeftButton()));
    connect(action_online,SIGNAL(triggered()),this,SLOT(pressButton()));
    connect(action_offline,SIGNAL(triggered()),this,SLOT(pressButton()));
    this->setContextMenu(tray_menu);
}
