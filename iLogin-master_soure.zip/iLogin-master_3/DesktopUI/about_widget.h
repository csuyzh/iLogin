#ifndef ABOUT_WIDGET_H
#define ABOUT_WIDGET_H

#include <QWidget>

class PushButton;
class QLabel;

class AboutWidget : public QWidget
{
    Q_OBJECT
public:
    explicit AboutWidget(QWidget *parent = 0);
    ~AboutWidget();
protected:
    void paintEvent(QPaintEvent *);
    void mouseMoveEvent(QMouseEvent *);
    void mousePressEvent(QMouseEvent *);
    void mouseReleaseEvent(QMouseEvent *);
private:
    QPoint press_point;//鼠标按下去的点
    bool is_move;

    PushButton *button_close;
    QLabel *label_title;
};

#endif // ABOUT_WIDGET_H
